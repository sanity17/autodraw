using System;
using System.Runtime.InteropServices;

namespace AutoDraw_ColorIntegration
{
    public static class InterceptionDriver
    {
        [DllImport("interception.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr interception_create_context();

        [DllImport("interception.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int interception_send(IntPtr context, int device, ref Stroke stroke, uint numStrokes);

        [StructLayout(LayoutKind.Sequential)]
        public struct MouseStroke
        {
            public ushort state;
            public ushort flags;
            public short rolling;
            public int x;
            public int y;
            public uint information;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct Stroke
        {
            [FieldOffset(0)] public MouseStroke mouse;
            [FieldOffset(0)] public byte rawData;
        }

        public const ushort LeftDown = 1;
        public const ushort LeftUp = 2;

        public static void SendClick(IntPtr context, int deviceId, int x, int y)
        {
            Stroke move = new Stroke { mouse = new MouseStroke { x = x, y = y, flags = 1 } };
            Stroke down = new Stroke { mouse = new MouseStroke { state = LeftDown } };
            Stroke up = new Stroke { mouse = new MouseStroke { state = LeftUp } };

            interception_send(context, deviceId, ref move, 1);
            interception_send(context, deviceId, ref down, 1);
            interception_send(context, deviceId, ref up, 1);
        }
    }
}
