using Avalonia.Controls;
using Avalonia.Input;

namespace AutoDraw_ColorIntegration
{
    public partial class CalibrationWindow : Window
    {
        private int step = 0;
        public ColorPickerMath PickerData { get; } = new ColorPickerMath();

        public CalibrationWindow()
        {
            InitializeComponent();
        }

        private void OnPointerPressed(object sender, PointerPressedEventArgs e)
        {
            var point = e.GetPosition(this);
            var textBlock = this.FindControl<TextBlock>("InstructionText");

            switch (step)
            {
                case 0:
                    PickerData.WheelCenterX = (float)point.X;
                    PickerData.WheelCenterY = (float)point.Y;
                    textBlock.Text = "Click Pure Red (Left Outer Edge)";
                    break;
                case 1:
                    PickerData.WheelRadius = (float)System.Math.Abs(PickerData.WheelCenterX - point.X);
                    textBlock.Text = "Click Top of Slider (White)";
                    break;
                case 2:
                    PickerData.SliderX = (float)point.X;
                    PickerData.SliderTopY = (float)point.Y;
                    textBlock.Text = "Click Bottom of Slider (Black)";
                    break;
                case 3:
                    PickerData.SliderBottomY = (float)point.Y;
                    this.Close();
                    break;
            }
            step++;
        }
    }
}
