using System;

namespace AutoDraw_ColorIntegration
{
    public class ColorPickerMath
    {
        public float WheelCenterX { get; set; }
        public float WheelCenterY { get; set; }
        public float WheelRadius { get; set; }
        public float SliderX { get; set; }
        public float SliderTopY { get; set; }
        public float SliderBottomY { get; set; }

        public (int x, int y) GetWheelCoords(float h, float s)
        {
            double hueRadians = h * (Math.PI / 180.0);
            double theta_calc = Math.PI - hueRadians;
            double r = s * WheelRadius;

            int clickX = (int)Math.Round(WheelCenterX + r * Math.Cos(theta_calc));
            int clickY = (int)Math.Round(WheelCenterY + r * Math.Sin(theta_calc));

            return (clickX, clickY);
        }

        public (int x, int y) GetSliderCoords(float v)
        {
            int clickY = (int)Math.Round(SliderBottomY + v * (SliderTopY - SliderBottomY));
            return ((int)Math.Round(SliderX), clickY);
        }
    }
}
